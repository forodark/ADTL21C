===========================================================
     Online Shopping System by Glen Bautista - README
===========================================================

Welcome to my Online Shopping System made in Java. I created a bunch of
demo accounts within the program, and made all the stores Pokemon themed :)
This program has many features, expanding on the specifications given.

**Instructions for Running the Program:**

1. Ensure that you have Java installed on your system.
3. Extract the contents of the zip file to your desired location.
4. Locate the 'RUN.bat' file in the extracted folder.
5. Double-click on 'RUN.bat' to start the program.

**Tester Accounts Information:**

Customer accounts:

- Email: glen@email.com
- Password: 1234

- Email: happy@email.com
- Password: 1234


Seller Accounts:

- Email: pmart@email.com
- Password: 123

- Email: eeevo@email.com
- Password: 456

- Email: splash@email.com
- Password: 789

- Email: pikachu@email.com
- Password: 246

- Email: rocket@email.com
- Password: 135

- Email: mysticmart@email.com
- Password: 789

- Email: floral.bloom@email.com
- Password: 135

- Email: aqua.bubbles@email.com
- Password: 246

- Email: dark.dungeon@email.com
- Password: 789

- Email: dragons.hoard@email.com
- Password: 135


